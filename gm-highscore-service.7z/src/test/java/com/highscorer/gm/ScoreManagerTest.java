package com.highscorer.gm;

import com.highscorer.gm.client.model.HighScore;
import com.highscorer.gm.client.model.UserScore;
import com.highscorer.gm.client.service.ScoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ScoreManagerTest {

    ScoreService scoreService;

    @BeforeEach
    public void setUp() {
        scoreService = new ScoreService();
    }

    @Test
    public void testSaveScore() {
        var levelId = 1;
        var userId = 42;
        var score = 500;
        var userScore = new UserScore(userId, score);
        scoreService.saveScore(userScore, levelId);
        HighScore highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(500, highScore.getHighScores().getFirst().getScore());
    }

    @Test
    public void testLevelIdWithoutScores() {
        var highScore = scoreService.getHighScore(555);
        assertEquals("[ ]", highScore.toString());
    }

    @Test
    public void testUniqueScorePerUser() {
        var levelId = 2;
        var userId = 42;
        var score = 500;
        HighScore highScore;
        var userScore1 = new UserScore(userId, score);
        scoreService.saveScore(userScore1, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(500, highScore.getHighScores().getFirst().getScore());
        var userScore2 = new UserScore(userId, score + 50);
        scoreService.saveScore(userScore2, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(550, highScore.getHighScores().getFirst().getScore());
        var userScore3 = new UserScore(userId, score - 50);
        scoreService.saveScore(userScore3, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(550, highScore.getHighScores().getFirst().getScore());
        var userScore4 = new UserScore(userId, score + 100);
        scoreService.saveScore(userScore4, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(600, highScore.getHighScores().getFirst().getScore());
    }

    @Test
    public void testSeveralScore() {
        var levelId = 3;
        HighScore highScore;
        var userScore1 = new UserScore(42, 500);
        scoreService.saveScore(userScore1, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(500, highScore.getHighScores().getFirst().getScore());
        var userScore2 = new UserScore(72, 450);
        scoreService.saveScore(userScore2, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(500, highScore.getHighScores().getFirst().getScore());
        assertEquals(72, highScore.getHighScores().getLast().getUserId());
        assertEquals(450, highScore.getHighScores().getLast().getScore());
        var userScore3 = new UserScore(42, 600);
        scoreService.saveScore(userScore3, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(42, highScore.getHighScores().getFirst().getUserId());
        assertEquals(600, highScore.getHighScores().getFirst().getScore());
        assertEquals(72, highScore.getHighScores().getLast().getUserId());
        assertEquals(450, highScore.getHighScores().getLast().getScore());
        var userScore4 = new UserScore(72, 700);
        scoreService.saveScore(userScore4, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(72, highScore.getHighScores().getFirst().getUserId());
        assertEquals(700, highScore.getHighScores().getFirst().getScore());
        assertEquals(42, highScore.getHighScores().getLast().getUserId());
        assertEquals(600, highScore.getHighScores().getLast().getScore());
        var userScore5 = new UserScore(10, 650);
        scoreService.saveScore(userScore5, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(3, highScore.getHighScores().size());
        assertEquals(72, highScore.getHighScores().getFirst().getUserId());
        assertEquals(700, highScore.getHighScores().getFirst().getScore());
        assertEquals(42, highScore.getHighScores().getLast().getUserId());
        assertEquals(600, highScore.getHighScores().getLast().getScore());
        assertEquals("""
                [ {
                  "userId" : 72,
                  "score" : 700
                }, {
                  "userId" : 10,
                  "score" : 650
                }, {
                  "userId" : 42,
                  "score" : 600
                } ]""", highScore.toString());
    }

    @Test
    public void testMaxLimitScore() {
        var levelId = 4;
        for (var i = 1; i < 16; i++) {
            UserScore userScore1 = new UserScore(i, i);
            scoreService.saveScore(userScore1, levelId);
        }
        var highScore = scoreService.getHighScore(levelId);
        assertEquals(15, highScore.getHighScores().size());
        int userId = 42;
        var userScore = new UserScore(userId, userId);
        scoreService.saveScore(userScore, levelId);
        highScore = scoreService.getHighScore(levelId);
        assertEquals(15, highScore.getHighScores().size());
    }

}
