package com.highscorer.gm;

import com.highscorer.gm.client.model.Session;
import com.highscorer.gm.client.service.SessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.util.AssertionErrors.assertFalse;
import static org.springframework.test.util.AssertionErrors.assertTrue;

public class SessionManagerTest {

    SessionService sessionService;

    @BeforeEach
    public void setUp() {
        sessionService = new SessionService();
    }

    @Test
    public void testCreateNewSession() {
        Session session = sessionService.createNewSession(42);
        System.out.println("session.getUserId() = " + session.getUserId());
        System.out.println("session.getCreatedTime() = " + session.getCreatedTime());
        System.out.println("session.getSessionKey() = " + session.getSessionKey());
        System.out.println("session = " + session);
        assertNotNull("Session Invalid", session.getSessionKey());
    }

    @Test
    public void testIsSessionValid() {
        Session session = sessionService.createNewSession(42);
        System.out.println("session = " + session);
        String sessionKey = session.getSessionKey();
        boolean valid = sessionService.isSessionValid(sessionKey);
        assertTrue("Session Invalid", valid);

    }

    @Test
    public void testIsSessionInvalid() {
        String sessionKey = UUID.randomUUID().toString().replace("-", "");
        boolean valid = sessionService.isSessionValid(sessionKey);
        assertFalse("Session Invalid", valid);
    }

}
