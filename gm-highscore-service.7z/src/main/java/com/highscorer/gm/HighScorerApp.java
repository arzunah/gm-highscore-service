package com.highscorer.gm;

import com.highscorer.gm.client.exception.BackEndException;
import com.highscorer.gm.client.service.GameService;
import com.highscorer.gm.server.filter.HttpFilter;
import com.highscorer.gm.server.handler.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Executors;

@SpringBootApplication
public class HighScorerApp {

    private static int PORT = 8081;

    public static void main(String... args) {
        // call to client app
        SpringApplication.run(HighScorerApp.class, args);

        // call to app server
        if (args.length > 0) {
            try {
                if (args.length == 2) {
                    if (args[0].equals("-p")) {
                        PORT = Integer.parseInt(args[1]);
                    } else {
                        throw new BackEndException("Invalid argument '" + args[0] + "'.");
                    }
                } else {
                    throw new BackEndException("Invalid number of arguments.");
                }
            } catch (Exception e) {
                System.err.println(e.getMessage());
                return;
            }
        }

        try {
            System.out.println("\n\n   Starting HTTPServer.");
            var hostName = "localhost";
            try {
                hostName = InetAddress.getLocalHost().getCanonicalHostName();
            } catch (UnknownHostException ex) {
                System.err.println("Unknown Host: " + ex);
            }
            var httpServer = HttpServer.create(new InetSocketAddress(PORT), 0);
            var httpContext = httpServer.createContext("/", new HttpHandler(GameService.getInstance()));
            httpContext.getFilters().add(new HttpFilter());
            var executorService = Executors.newCachedThreadPool();
            httpServer.setExecutor(executorService);
            httpServer.start();
            System.out.println("   HTTPServer started in http://" + hostName + ":" + PORT + "/");
            System.out.println("   Started HTTPServer Successfully!\n");
        } catch (Exception e) {
            System.err.println("Error with the HTTPServer.");
            System.err.println(e.getMessage());
        }

    }

}
