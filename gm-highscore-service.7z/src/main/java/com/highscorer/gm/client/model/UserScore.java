package com.highscorer.gm.client.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserScore implements Serializable, Comparable<UserScore> {

    private int userId;
    private int score;

    @Override
    public int compareTo(UserScore o) {
        var compare = Integer.compare(o.score, this.score);
        if (compare == 0 && o.userId != this.userId)
            compare = 1;
        return compare;
    }

}
