package com.highscorer.gm.client.service;

import com.highscorer.gm.client.exception.AuthorizationException;
import com.highscorer.gm.client.model.UserScore;
import com.highscorer.gm.client.scheduler.SessionCleanerScheduler;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameService {

    public volatile static GameService gameService;
    private final ScoreService scoreService;
    private final SessionService sessionService;

    public GameService(ScoreService scoreService, SessionService sessionService) {
        this.scoreService = scoreService;
        this.sessionService = sessionService;
        var sessionCleanerScheduler = new SessionCleanerScheduler(sessionService);
        sessionCleanerScheduler.startService();
    }

    public static GameService getInstance() {
        if (gameService == null) {
            synchronized (GameService.class) {
                if (gameService == null) {
                    gameService = new GameService(new ScoreService(), new SessionService());
                }
            }
        }
        return gameService;
    }

    public String login(int userId) {
        return sessionService.createNewSession(userId).getSessionKey();
    }

    public void score(String sessionKey, int levelId, int score) throws AuthorizationException {
        if (!sessionService.isSessionValid(sessionKey)) {
            throw new AuthorizationException();
        }
        var session = sessionService.getSessionActive(sessionKey);
        if (session == null) {
            throw new AuthorizationException();
        }
        var userScore = new UserScore(session.getUserId(), score);
        scoreService.saveScore(userScore, levelId);
    }

    public String highScoreList(int levelId) {
        var highScore = scoreService.getHighScore(levelId);
        return highScore.toString();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

}
