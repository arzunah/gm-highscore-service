package com.highscorer.gm.client.exception;

import com.highscorer.gm.client.common.Constants;

import java.io.Serial;

public class NotValidHttpException extends Exception {

    @Serial
    private static final long serialVersionUID = 4354356123447123492L;

    public NotValidHttpException() {
        super(Constants.GENERIC_ERROR_MESSAGE);
    }

    public NotValidHttpException(String msg) {
        super(msg);
    }
}
