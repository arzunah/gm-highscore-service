package com.highscorer.gm.client.exception;

import java.io.Serial;

public class BackEndException extends Exception {

    @Serial
    private static final long serialVersionUID = 2345365634347123492L;

    public BackEndException() {
        super();
    }

    public BackEndException(String msg) {
        super(msg);
    }

    public BackEndException(Exception ex) {
        super(ex);
    }
}
