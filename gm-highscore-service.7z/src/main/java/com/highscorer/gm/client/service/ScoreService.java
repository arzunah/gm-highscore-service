package com.highscorer.gm.client.service;

import com.highscorer.gm.client.model.HighScore;
import com.highscorer.gm.client.model.UserScore;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@SpringBootApplication
public class ScoreService {

    private final ConcurrentMap<Integer, HighScore> highScoresMap;

    public ScoreService() {
        highScoresMap = new ConcurrentHashMap<>();
    }

    public synchronized void saveScore(final UserScore userScore, final Integer levelId) {
        var highScore = highScoresMap.get(levelId);
        if (highScore == null) {
            highScore = new HighScore();
            highScoresMap.putIfAbsent(levelId, highScore);
        }
        highScore.add(userScore);
    }

    public HighScore getHighScore(final int levelId) {
        if (!highScoresMap.containsKey(levelId)) {
            return new HighScore();
        }
        return highScoresMap.get(levelId);
    }

}
