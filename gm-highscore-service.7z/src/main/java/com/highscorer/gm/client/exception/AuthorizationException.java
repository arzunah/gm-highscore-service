package com.highscorer.gm.client.exception;

import com.highscorer.gm.client.common.Constants;

import java.io.Serial;

public class AuthorizationException extends Exception {

    @Serial
    private static final long serialVersionUID = 5163433612347123492L;

    public AuthorizationException() {
        super(Constants.AUTHORIZATION_ERROR);
    }

    public AuthorizationException(String msg) {
        super(msg);
    }
}
