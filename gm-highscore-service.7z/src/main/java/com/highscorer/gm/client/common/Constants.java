package com.highscorer.gm.client.common;

public class Constants {

    public static final int MAX_SCORES = 15;
    public static final int TIME_TO_LIVE = 600000;

    public static final String AUTHORIZATION_ERROR = "Authorization Error";
    public static final String GENERIC_ERROR_MESSAGE = "Something wrong happened.";

}
