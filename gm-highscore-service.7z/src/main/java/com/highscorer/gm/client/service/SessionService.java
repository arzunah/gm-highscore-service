package com.highscorer.gm.client.service;

import com.highscorer.gm.client.common.Constants;
import com.highscorer.gm.client.model.Session;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@SpringBootApplication
public class SessionService {

    private final ConcurrentMap<String, Session> sessionActives;

    public SessionService() {
        sessionActives = new ConcurrentHashMap<>();
    }

    public synchronized Session createNewSession(final Integer userId) {
        final var now = System.currentTimeMillis();
        final var newSessionKey = UUID.randomUUID().toString().replace("-", "");
        final var session = new Session(userId, newSessionKey, now);
        sessionActives.put(newSessionKey, session);
        return session;
    }

    public synchronized boolean isSessionValid(final String sessionKey) {
        var sessionActive = sessionActives.get(sessionKey);
        if (sessionActive != null) {
            if ((System.currentTimeMillis() - sessionActive.getCreatedTime()) > Constants.TIME_TO_LIVE) {
                sessionActives.remove(sessionKey);
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    public Session getSessionActive(final String sessionKey) {
        return sessionActives.get(sessionKey);
    }

    public synchronized void removeInvalidSessions() {
        var now = System.currentTimeMillis();
        for (var session : new ArrayList<>(sessionActives.values())) {
            if ((now - session.getCreatedTime()) > Constants.TIME_TO_LIVE) {
                sessionActives.remove(session.getSessionKey());
            }
        }
    }

}
