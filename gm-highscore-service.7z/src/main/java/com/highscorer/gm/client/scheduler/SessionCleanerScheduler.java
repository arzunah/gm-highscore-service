package com.highscorer.gm.client.scheduler;

import com.highscorer.gm.client.common.Constants;
import com.highscorer.gm.client.service.SessionService;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
public class SessionCleanerScheduler implements Runnable {

    private final SessionService sessionService;

    public SessionCleanerScheduler(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    public void startService() {
        var service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(this, Constants.TIME_TO_LIVE, Constants.TIME_TO_LIVE, TimeUnit.MILLISECONDS);
    }

    @Override
    public void run() {
        sessionService.removeInvalidSessions();
    }

}
