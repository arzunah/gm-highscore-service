package com.highscorer.gm.client.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.highscorer.gm.client.common.Constants;
import lombok.Data;
import lombok.SneakyThrows;

import java.io.Serializable;
import java.util.concurrent.ConcurrentSkipListSet;

@Data
public class HighScore implements Serializable {

    private final ConcurrentSkipListSet<UserScore> highScores;

    public HighScore() {
        this.highScores = new ConcurrentSkipListSet<>();
    }

    public void add(UserScore userScore) {
        var oldUserScore = findExistingUserScore(userScore);

        if (oldUserScore != null) {
            if (oldUserScore.getScore() >= userScore.getScore())
                return;
            highScores.remove(oldUserScore);
        }
        highScores.add(userScore);
        if (highScores.size() > Constants.MAX_SCORES) {
            highScores.pollLast();
        }
    }

    public UserScore findExistingUserScore(UserScore userScore) {
        for (var us : highScores) {
            if (us.getUserId() == userScore.getUserId()) {
                return us;
            }
        }
        return null;
    }

    @SneakyThrows
    @Override
    public String toString() {
        return new ObjectMapper().writer().withDefaultPrettyPrinter().writeValueAsString(highScores);
    }

}
