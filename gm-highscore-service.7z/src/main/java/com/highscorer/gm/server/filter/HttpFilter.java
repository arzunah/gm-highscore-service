package com.highscorer.gm.server.filter;

import com.highscorer.gm.client.exception.BackEndException;
import com.highscorer.gm.client.exception.NotValidHttpException;
import com.highscorer.gm.server.common.Constants;
import com.sun.net.httpserver.Filter;
import com.sun.net.httpserver.HttpExchange;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static com.highscorer.gm.client.common.Constants.GENERIC_ERROR_MESSAGE;

public class HttpFilter extends Filter {

    private static final String LOGIN_PATTERN = "/(\\d*)/login";
    private static final String SCORE_PATTERN = "/(\\d*)/score\\?sessionkey=(.*)";
    private static final String HIGH_SCORE_LIST_PATTERN = "/(\\d*)/highscorelist";

    @Override
    public void doFilter(HttpExchange httpExchange, Chain chain) throws IOException {
        try {
            Map<String, String> parameters;
            //validate the URL from the request
            var uri = httpExchange.getRequestURI().toString();
            if (uri.matches(LOGIN_PATTERN)) {
                parameters = parseLoginParameters(httpExchange);
            } else if (uri.matches(SCORE_PATTERN)) {
                parameters = parseScoreParameters(httpExchange);
            } else if (uri.matches(HIGH_SCORE_LIST_PATTERN)) {
                parameters = parseHighScoreListParameters(httpExchange);
            } else {
                //is an invalid url
                throw new NotValidHttpException("Invalid URL.");
            }
            //Pass the parameter to the BackEndHttpHandler
            httpExchange.setAttribute(Constants.PARAMETER_ATTRIBUTE, parameters);
            chain.doFilter(httpExchange);
        } catch (NotValidHttpException ex) {
            exceptionHandledResponse(ex.getMessage(), httpExchange, HttpURLConnection.HTTP_NOT_FOUND);
        } catch (Exception ex) {
            exceptionHandledResponse(ex.getMessage(), httpExchange, HttpURLConnection.HTTP_BAD_REQUEST);
        }
    }

    private static Map<String, String> parseLoginParameters(HttpExchange httpExchange) throws NotValidHttpException {
        validHttpMethod(httpExchange, "GET");
        var parameters = new HashMap<String, String>();
        var uri = httpExchange.getRequestURI().toString();
        var userId = uri.split("/")[1];
        parameters.put(Constants.REQUEST_PARAMETER, Constants.LOGIN_REQUEST);
        parameters.put(Constants.USER_ID_PARAMETER, userId);
        return parameters;
    }

    private static Map<String, String> parseScoreParameters(HttpExchange httpExchange) throws NotValidHttpException, BackEndException {
        validHttpMethod(httpExchange, "POST");
        var parameters = new HashMap<String, String>();
        var uri = httpExchange.getRequestURI().toString();
        var uriStrings = uri.split("/");
        var levelId = uriStrings[1];
        var paramsStrings = uriStrings[2].split(Constants.SESSION_KEY_PARAMETER + "=");
        var sessionKey = paramsStrings[1];
        var score = "";
        try {
            var inputStreamReader = new InputStreamReader(httpExchange.getRequestBody(), StandardCharsets.UTF_8);
            try (inputStreamReader; var bufferedReader = new BufferedReader(inputStreamReader)) {
                score = bufferedReader.readLine();
            }
        } catch (Exception ex) {
            throw new BackEndException(ex.getMessage());
        }
        parameters.put(Constants.REQUEST_PARAMETER, Constants.SCORE_REQUEST);
        parameters.put(Constants.LEVEL_ID_PARAMETER, levelId);
        parameters.put(Constants.SESSION_KEY_PARAMETER, sessionKey);
        parameters.put(Constants.SCORE_PARAMETER, score);
        return parameters;
    }

    private static Map<String, String> parseHighScoreListParameters(HttpExchange httpExchange) throws NotValidHttpException {
        validHttpMethod(httpExchange, "GET");
        var parameters = new HashMap<String, String>();
        var uri = httpExchange.getRequestURI().toString();
        var levelId = uri.split("/")[1];
        parameters.put(Constants.REQUEST_PARAMETER, Constants.HIGH_SCORE_LIST_REQUEST);
        parameters.put(Constants.LEVEL_ID_PARAMETER, levelId);
        return parameters;
    }

    private static void validHttpMethod(HttpExchange httpExchange, String method) throws NotValidHttpException {
        if (!method.equalsIgnoreCase(httpExchange.getRequestMethod())) {
            throw new NotValidHttpException("Method '" + httpExchange.getRequestMethod() + "' is not supported.");
        }
    }

    private void exceptionHandledResponse(String message, HttpExchange httpExchange, int statusCode) throws IOException {
        if (message == null || message.isEmpty())
            message = GENERIC_ERROR_MESSAGE;
        httpExchange.sendResponseHeaders(statusCode, message.length());
        var os = httpExchange.getResponseBody();
        os.write(message.getBytes());
        os.close();
    }

    @Override
    public String description() {
        return "Manages the Http Requests.";
    }

}
