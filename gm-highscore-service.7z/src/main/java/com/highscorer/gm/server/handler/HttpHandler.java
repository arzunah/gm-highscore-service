package com.highscorer.gm.server.handler;

import com.highscorer.gm.client.exception.AuthorizationException;
import com.highscorer.gm.client.exception.NotValidHttpException;
import com.highscorer.gm.client.service.GameService;
import com.highscorer.gm.server.common.Constants;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Map;

import static com.highscorer.gm.client.common.Constants.GENERIC_ERROR_MESSAGE;

public class HttpHandler implements com.sun.net.httpserver.HttpHandler {

    private final GameService gameService;

    public HttpHandler(GameService gameService) {
        this.gameService = gameService;
    }

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        var httpBody = "";
        int httpCode = HttpURLConnection.HTTP_OK;
        var parameters = (Map<String, String>) httpExchange.getAttribute(Constants.PARAMETER_ATTRIBUTE);
        var request = parameters.get(Constants.REQUEST_PARAMETER);
        try {
            switch (request) {
                case Constants.LOGIN_REQUEST:
                    final var userId = Integer.parseInt(parameters.get(Constants.USER_ID_PARAMETER));
                    httpBody = gameService.login(userId);
                    break;
                case Constants.SCORE_REQUEST:
                    final var sessionKey = parameters.get(Constants.SESSION_KEY_PARAMETER);
                    final var score = Integer.parseInt(parameters.get(Constants.SCORE_PARAMETER));
                    final var levelId = Integer.parseInt(parameters.get(Constants.LEVEL_ID_PARAMETER));
                    gameService.score(sessionKey, levelId, score);
                    break;
                case Constants.HIGH_SCORE_LIST_REQUEST:
                    final var levelId1 = Integer.parseInt(parameters.get(Constants.LEVEL_ID_PARAMETER));
                    httpBody = gameService.highScoreList(levelId1);
                    break;
                default:
                    throw new NotValidHttpException("Invalid Request.");
            }
        } catch (NumberFormatException ex) {
            httpBody = "Invalid number format.";
            httpCode = HttpURLConnection.HTTP_BAD_REQUEST;
        } catch (NotValidHttpException ex) {
            httpBody = ex.getMessage();
            httpCode = HttpURLConnection.HTTP_NOT_FOUND;
        } catch (AuthorizationException ex) {
            httpBody = ex.getMessage();
            httpCode = HttpURLConnection.HTTP_UNAUTHORIZED;
        } catch (Exception ex) {
            httpBody = GENERIC_ERROR_MESSAGE;
            httpCode = HttpURLConnection.HTTP_INTERNAL_ERROR;
        }
        httpExchange.getResponseHeaders().add(Constants.CONTENT_TYPE, Constants.CONTENT_TEXT);
        httpExchange.sendResponseHeaders(httpCode, httpBody.length());
        var os = httpExchange.getResponseBody();
        os.write(httpBody.getBytes());
        os.close();
    }

}
