# gm-highscore-service

#### Background

You are working in a team that is building a high-performance system for multi-tenant,
multi-player gaming. Product your team has worked on is already launched in production
with multiple titles and is seeing an exponential growth in consumption and customer
engagement. As such, stability and performance of the system is of utmost importance to
every delivery from your team.
One of the most popular new features is the ability to track highscores across different
gaming titles for each and every user, and to allow both display of per title leaderboards as
well as a personal highscores and rankings for each user across all titles.
Your team is working with Java, Spring Boot and MongoDB, running everything in a
containerized environment with centralized logging reading structured log output from your
application.
All public communication is happening via a centralized API Gateway, which handles
security and authentication for underlying services.
You are tasked with building out this new highscore functionality. You have also discussed
with your team lead that a simple way to discover titles that exist in the system would be
extremely beneficial for this and other functionalities to come.

#### Requirements

Implement a highscore service that exposes a REST-based API that allows for:
● Registering a score for a title and user
● Fetching a list of highscores (ranked list of users) for a title
● Fetching of a user's highscore and rank per title in the system
Implement a way for highscore service (and other future services) to enumerate gaming
titles that are registered in the system.

#### Technical requirements

Scores should be persisted and survive service restarts.
Services should be executable in a container environment as well as stand-alone.
It should be possible to configure run-time aspects of the services (e.g location of
dependencies, log level, etc) without rebuilding of the application.
Correctness of operation should be proven through common means.

#### Deliverables

Upon task completion, please provide a ZIP file containing at least the following:
● Source code
● Build instructions
● Runnable manifests or anything required to run with e.g Docker Compose
● Documentation explaining technical choices, limitations and any future improvements
and considerations.

#### Tech Stacks Used

- Springboot 3.2.1
- Java 21
- Maven 3.9.6
- Postman

#### How to test and run the app

> mvn clean install -U

> mvn spring-boot:run

#### How to login, save score and fetch high score for a user

1. login url -> ```GET http://localhost:8081/10482096/login```
   Note : save the session key ( for eg: ```231df0a19cf44f8d8e08bae6f8cd50fd``` ) so that you can use it to save scores
2. save score
   url -> ```POST -d 10055 http://localhost:8081/10012001/score?sessionkey=231df0a19cf44f8d8e08bae6f8cd50fd```
   Note : repeat step (2) to save as many high scores as needed
3. get/fetch highscore url -> ```GET http://localhost:8081/10482096/highscorelist```

